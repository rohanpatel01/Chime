"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handle = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client_apigatewaymanagementapi_1 = require("@aws-sdk/client-apigatewaymanagementapi");
const util_1 = require("util");
const responseOK = {
    statusCode: 200,
    body: "",
};
const dynamodbClient = new client_dynamodb_1.DynamoDBClient({});
const apiGatewayManagementApi = new client_apigatewaymanagementapi_1.ApiGatewayManagementApi({
    endpoint: process.env["WSSAPIGATEWAYENDPOINT"],
});
const clientsTable = process.env["CLIENTS_TABLE_NAME"] || "";
const textEncoder = new util_1.TextEncoder();
let dateTime;
const handle = async (event) => {
    const connectionId = event.requestContext.connectionId;
    const routeKey = event.requestContext.routeKey;
    const body = event.body || "";
    switch (routeKey) {
        case "$connect":
            return handleConnect(connectionId);
        case "$disconnect":
            return handleDisconnect(connectionId);
        case "msg":
            return handleMsg(connectionId, body);
    }
    return responseOK; // changed
};
exports.handle = handle;
const handleConnect = async (connectionId) => {
    await dynamodbClient.send(new client_dynamodb_1.PutItemCommand({
        TableName: clientsTable,
        Item: {
            connectionId: {
                S: connectionId,
            },
        },
    }));
    // was send date time but handle this with react front end
    return responseOK;
};
const handleDisconnect = async (connectionId) => {
    await dynamodbClient.send(new client_dynamodb_1.DeleteItemCommand({
        TableName: clientsTable,
        Key: {
            connectionId: {
                S: connectionId,
            },
        },
    }));
    return responseOK;
};
const handleMsg = async (thisConnectionId, body) => {
    const output = await dynamodbClient.send(new client_dynamodb_1.ScanCommand({
        TableName: clientsTable,
    }));
    if (output.Count && output.Count > 0) {
        for (const item of output.Items || []) {
            if (item["connectionId"].S !== thisConnectionId) {
                sendMessage(item["connectionId"].S, body);
                console.log("sent message");
            }
        }
    }
    else {
        await sendMessage(thisConnectionId, JSON.stringify({ action: "msg", type: "warning", body: "no recipient" }));
    }
    return responseOK;
};
const sendMessage = async (connectionId, body) => {
    try {
        await apiGatewayManagementApi.postToConnection({
            ConnectionId: connectionId,
            Data: textEncoder.encode(body),
        });
    }
    catch (e) {
        if (e instanceof client_apigatewaymanagementapi_1.GoneException) {
            await handleDisconnect(connectionId);
            return;
        }
        throw e;
    }
};
//# sourceMappingURL=handlers.js.map